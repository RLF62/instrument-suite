# HP 6033A Web Controller

A Raspberry Pi-based web interface for monitoring and controlling the
Hewlett-Packard HP 6033A programmable DC power supply through USB-GPIB.

Developed and successfully tested with a real HP 6033A.

## Features

- Modern browser-based dashboard
- Classic-style instrument interface
- Live voltage and current monitoring
- Programmable voltage and current settings
- Output enable/disable control
- Remote control safety protections
- HTTPS support through Nginx
- Authentication for protected control operations
- Built-in documentation and command reference

## Screenshots

### Classic front panel

![Classic HP 6033A front panel with LED-style voltage and current readouts and the adjustment knob](screenshots/classic-dashboard.png)

### Modern dashboard

![Modern HP 6033A dashboard with live readings, voltage and current presets, and output controls](screenshots/modern-dashboard.png)

### Classic setup and extra controls

![Classic setup panel with control preferences, Software Updates, and editable front-panel labels](screenshots/classic-setup.png)

This example shows the Software Updates panel with the optional update helper unavailable.

## Verified Hardware

- Hewlett-Packard HP 6033A programmable DC power supply
- Raspberry Pi 3 B+
- XyphroLabs UsbGpib V2 USB-GPIB adapter

The HP 6033A is rated for 0â€“20 V, 0â€“30 A, and 200 W.

## Compatibility

This software has been successfully tested with the HP 6033A.

Other HP programmable power supplies using compatible GPIB commands
may also work, but have not yet been verified.

Reports of successful operation with other models are welcome.

## Software

- Python 3
- Flask
- PyVISA and PyVISA-py
- Gunicorn
- Nginx

## USB-GPIB Adapter

This project uses the XyphroLabs UsbGpib V2 adapter.

Original project:
https://github.com/xyphro/UsbGpib

Thanks to the developer for making this hardware interface available.

## Three-instrument suite

Add the [HP 34401A controller](https://github.com/RLF62/hp34401a-web-controller) and optional [Tektronix controller](https://github.com/RLF62/tektronix-ethernet-controller) using the [suite installation guide](INSTRUMENT_SUITE.md). The meter add-on provides the shared adapter owner; all GPIB applications must use it.

## Installation

**Validated on fresh Raspberry Pi OS Lite (64-bit) in HTTPS and HTTP-only modes.**

On a fresh Raspberry Pi OS installation, download and extract the
[GitHub main ZIP](https://github.com/RLF62/hp6033a-web-controller/archive/refs/heads/main.zip)
and open a terminal in the extracted project directory as the controller user.
The installer uses `sudo` for system setup.

    bash install.sh

Setup first explains the connection and password options. Choose HTTPS for
an encrypted browser connection with optional control authentication. Choose
HTTP only on a trusted home LAN to skip certificates, the HTTPS redirect, and
dashboard passwords. Anyone on the allowed subnet can enable remote control
in HTTP-only mode. Browser updates require HTTPS. Command-line updates support
both modes.

Enter the controller hostname or IP and its permitted LAN subnet. When prompted,
reconnect the USB-GPIB adapter. Setup saves its VISA address if exactly one
supported adapter is detected, or prints manual steps if needed. After checking
the status API and both dashboards and enabling automatic startup, setup prints
the dashboard URL. See the [installation guide](static/docs/installation.html).

The installer will not overwrite an existing HP 6033A installation.

### Versioned installation and upgrades

When a reviewed stable release is available, the [installation guide](static/docs/installation.html)
shows how to download its pinned tag, verify the full commit and Git objects,
and start the installer. Get the tag and commit from the
[release notes](https://github.com/RLF62/hp6033a-web-controller/releases).

For a first upgrade, use the download command in the installation guide with
its update arguments. You can also run the updater from a reviewed release
checkout. It downloads the selected stable tag itself. Replace the placeholders and use
the controller's current address, including its HTTP or HTTPS scheme.

```bash
bash update.sh --check
bash update.sh --release '<stable-tag>' --expect-commit '<full-commit>' --url https://hp6033a.local --dry-run
bash update.sh --release '<stable-tag>' --expect-commit '<full-commit>' --url https://hp6033a.local
```

`--check` is safe to run periodically as the controller user. It reports stable
tags and release links. Applying an upgrade is a separate, explicit command.
An unversioned legacy install is identified by an app file fingerprint.
The updater requires connected readback with output off and remote programming
disabled. See [recovery](static/docs/recovery.html) for backup and rollback.

### Software Updates in the dashboards

On a fresh HTTPS installation, opt in to Software Updates when prompted and create
a separate update administrator password. Open Setup in Modern or
Setup & Extra Controls in Classic to see the installed version, latest
published stable GitHub release, release notes, and update status.
The helper checks GitHub every six hours. Installing requires confirming a
specific version and commit with the update administrator password, even
when power-supply control is password-free.

For an existing deployment, first install the compatible application using
the verified CLI updater, then provision the helper once from the reviewed
checkout. See the [installation guide](static/docs/installation.html#web-updates).
Release discovery uses published, non-prerelease GitHub releases with a stable
version tag. The helper leaves settings, Nginx, and TLS configuration in place
and keeps protected system backups. It stops if the instrument is disconnected,
the physical output cannot be confirmed off, or remote programming is enabled.

### Control authentication and dashboard settings

The installer defaults to password-protected control and creates a separate
controller login for HTTPS installations. Choose password-free control only on a trusted
LAN without internet exposure. Both HTTPS control password options retain
the configured LAN allowlist and the instrument safety checks.

Open **Setup** in Modern or **Setup & Extra Controls** below the Classic
instrument panel to find the confirmation and control password settings. Changing the mode always requires the controller
credentials. A mode change disarms remote programming and leaves the power
supply's physical output in its current state.

Fresh HTTPS installs enable the authentication policy button. To enable it on a previously
installed controller after updating its application and deployment scripts,
run this once on the Raspberry Pi:

```bash
sudo bash /home/pi/hp6033a/deploy/set-control-auth.sh dashboard
```

The script validates Nginx before reloading and restores the previous site
configuration if activation fails. It prompts for credentials if none exist.
Reload the dashboard to use the button. The explicit `protected` and
`password-free` command modes remain available for SSH-only administration
and disable dashboard policy changes.

The confirmation checkbox is saved per browser profile and controller URL.
In Classic, open **Setup & Extra Controls** to edit the front-panel
labels. The controller saves these labels in its configuration for all browsers.
Changing a label has no effect on electrical limits.

## Safety

This software controls a physical power supply capable of delivering
substantial electrical power.

Verify voltage and current limits before enabling the output.

Remote output control is restricted by default and requires
deliberate configuration and confirmation.

Never rely on software alone for electrical safety.

## Project Status

- HP 6033A communication: Verified
- Raspberry Pi 3 B+ operation: Verified
- Web controller: Operational
- Clean installer: HTTPS and HTTP-only verified on fresh Raspberry Pi OS Lite (64-bit)
- Other HP models: Not yet tested

## Contributions

Testing reports, bug reports, documentation improvements, and
compatibility information for additional HP power supplies are welcome.

### Shared instrument menu

After successful installation, the installer registers with the optional [Fischer Instrument Suite](https://github.com/RLF62/instrument-suite) manager. Missing or busy managers report registration as pending without failing installation. Existing integrated and legacy services are protected from removal until migrated to separate services. Registration sends no instrument commands.

## Independent services behind HTTPS

The shared suite now includes the gateway and deployment-policy support used to separate legacy controllers while preserving existing HTTPS URLs and control authentication. After a completed migration, each controller can be removed and reinstalled without taking down the suite or the other instruments. See the [gateway and migration guide](https://github.com/RLF62/instrument-suite/blob/main/GATEWAY_MIGRATION.md). Existing legacy installations still require an attended migration; installing the catalog alone does not perform it.


## Dashboard icons

The controller includes local favicon sizes 16, 32 and 48 px, an Apple touch
icon at 180 px, and Android home-screen icons at 192 and 512 px. Icons and the
web app manifest use same-origin paths for HTTP and HTTPS. The two HP
controllers use the existing HP artwork; the Tektronix controller uses the
supplied Tektronix artwork. Browser tab icons may need a hard refresh after
upgrading. Existing Android shortcuts may need to be added again.

The shared suite and standalone installers retain these assets. Icon updates
do not change instrument configuration or issue instrument commands.
