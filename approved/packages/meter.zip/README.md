# HP 34401A Web Controller

Classic photographic and Modern dashboards for the HP 34401A, integrated with the [HP 6033A controller](https://github.com/RLF62/hp6033a-web-controller) and the optional [Tektronix Ethernet controller](https://github.com/RLF62/tektronix-ethernet-controller).

![Classic meter dashboard](hp34401a/static/docs/images/classic.png)

## Features

- DC/AC voltage and current, resistance, frequency/period, continuity/diode and DC ratio.
- Primary/shifted buttons, state readback, range, digits, math and explicit web menu equivalents.
- Optional control guides, font/color/transparency preferences, live history chart.
- Shared Customize layout: move, resize, hide/show boxes; separate desktop/mobile arrangements.
- Offline HTML manual with five screenshots, button mappings and troubleshooting.
- One shared adapter broker around complete transactions, bounded timeouts and meter cooldown.
- [Add instruments](CATALOG.md): approved local packages, browser installation progress, automatic registration/navigation, and optional automatic opening after install.

## Installation

Choose **meter only** with `bash install.sh` to install without the supply application, or choose the existing-supply add-on. Both modes use the same coordinated adapter backend. See [meter-only setup and optional navigation](STANDALONE.md). The supported account is `pi` on Raspberry Pi OS; other usernames/paths are not yet supported.

For an existing HP 6033A base controller at `/home/pi/hp6033a`, the integration commands are:

Download/extract this repository into a staging directory distinct from `/home/pi/instrument-suite`. From that directory:

```sh
/home/pi/hp6033a/venv/bin/python install.py --check
/home/pi/hp6033a/venv/bin/python install.py --apply
```

The check stages and validates the HP integration and runs software tests without hardware access. Apply backs up the existing application/suite and systemd files, stops participating services, installs the reviewed source, retains existing configuration bytes, and restarts services. A fresh shared-adapter configuration starts with hardware disabled and meter writes blocked. No instrument reset, measurement, output or setpoint command is sent by the installer. Activation restarts the web services, so schedule an interruption and pause acquisition first.

Open `/multimeter/classic`, `/multimeter/modern` or `/multimeter/assets/docs/index.html` on the controller host. Navigation uses the current host. No public internet assets are needed for the dashboards or manual.

See [INSTALL.md](INSTALL.md) for the complete three-instrument process, first hardware checks, updates and rollback.

## Verification status

The connected HP 34401A returned `HEWLETT-PACKARD,34401A,0,10-5-2`. Function selection and configuration readbacks, immediate/BUS acquisition and basic math were exercised. AC digit shortcuts are web masks on this firmware. Concurrent meter samples/supply readback, meter-off timeout isolation, and meter recovery were verified through one adapter on the live Pi. External pulse capture and physical Local annunciator behavior remain pending. This is a development integration, not a calibrated accuracy claim or a fully validated clean-install release.

## Documentation and licensing

[Read the HTML manual source](hp34401a/static/docs/index.html), or open it locally after extracting the repository. The installed Documentation link is available in both dashboards.

Photo by Afandrf, with prior edits attributed to Pittigrilli. The modified panel and screenshots remain [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/). [Attribution and modification details](hp34401a/static/ATTRIBUTION.txt). Application source has no separate redistribution license granted here; image/document licensing does not silently assign an application-code license. No manufacturer PDF is bundled. Runtime configuration, passwords and personal capture files are excluded.

### Shared instrument menu

After successful installation, the installer asks the optional local instrument manager to register the controller. Missing or busy managers leave installation successful and report registration as pending; the manager also refreshes installed controllers periodically. Registration does not send instrument commands. Standalone installations work without the manager.
