# Fischer Lab Tektronix Ethernet controller — v0.3.2

Development build tested with a Raspberry Pi and an Ethernet-connected scope. The front panel says TDS 3032B; the instrument reports TDS 3052B firmware v3.27. The returned identity is shown in Instrument details. No model-configuration commands are used.

The working HP 6033A controller is separate. The production server was not modified.

## Install or update

Install `python3-venv`, `python3-pip` and `curl` on Raspberry Pi OS. Extract this repository to a separate staging folder. To prepare an isolated environment on a new host:

```sh
python3 -m venv ~/tektronix-controller-venv
~/tektronix-controller-venv/bin/pip install -r requirements.txt
bash install.sh --check
bash install.sh --apply
```

The installer retains runtime preferences/captures, backs up managed files and the user unit, and enables startup after logout/reboot. `sudo` is used for lingering only. The service listens on trusted-LAN HTTP port 8081; it does not inherit HP HTTPS authentication. [Three-instrument setup](https://github.com/RLF62/hp34401a-web-controller/blob/main/INSTALL.md). Review DEPLOYMENT.md for hardware evidence and remaining limits. No clean-OS install is claimed as verified yet.

## Open the controller

- Dashboard: http://CONTROLLER_HOST:8081/
- Setup: http://CONTROLLER_HOST:8081/setup
- Documentation: http://CONTROLLER_HOST:8081/docs/

Use the development Pi's address in these URLs. Setup's **Scope connection address** is the address of the instrument, not the Pi. It tells the controller where to find the scope and does not change the address configured on the scope.

Setup supports an IPv4 address or hostname, Test Connection, Save, and a 1â€“30 second operation timeout (default 6). Test uses the entered address without saving. Save is permitted while the scope is offline. The page and saved preferences remain accessible offline.

## Measurements

The dashboard has a saved list of up to 20 entries. Each entry independently selects CH1 or CH2 and Frequency, Period, Peak-to-peak, RMS voltage, or Mean voltage. Add, remove and save entries. Refresh manually or enable automatic refresh.

The scope's own measurement display has four slots. Check **On scope** for at most four dashboard entries and explicitly press **Apply selected to scope**. Slot source, type and enabled state are read back. Unselected slots are turned off. Applying an empty selection hides all four. The source channel must already be enabled; the controller does not silently turn it on. Saving dashboard entries does not apply them to the scope.

Measurement DATA? qualifiers distinguish errors from warnings. Finite values with warning 541 (low signal amplitude), 542 (unstable distribution) or 543 (limited resolution) are shown as uncertain with plain-language explanations. Invalid/nonfinite/sentinel readings remain unavailable. Status code and raw response are in Reading details. An off channel returns no numeric result.

An active on-screen slot matching the entry channel/type is read directly with MEASn:DATA?. Other measurement requests temporarily use the immediate-measurement source and type, then restore and verify them. They do not rewrite the scope's display slots. Readings are sequential, can span several acquisitions, and use the instrument's existing measurement gate/reference settings. The five initial types are the currently verified dashboard choices.

## Waveform CSV

CH1 and CH2 downloads contain actual stored waveform values, not points digitized from the screen.

The controller requests signed, 16-bit, big-endian data using WAVFRM?, which supplies the record's preamble and binary data. It validates binary block length, sample count, format, units and finite scaling values.

Conversion uses:

    time_seconds = xzero + xincr * (zero_based_point_index - pt_off)
    voltage_volts = yzero + ymult * (raw_sample - yoff)

A Sample/Average record has time_seconds, voltage_volts and raw_sample columns. Peak Detect/Envelope records use one row per min/max pair with time_seconds, voltage_min_volts, voltage_max_volts, raw_min and raw_max. A verified 10000-value Peak Detect record produced 5000 min/max rows.

Metadata includes channel, reported identity, host waveform-read timestamp in UTC, waveform identifier, point count/format, scaling factors, and acquisition state before/after. The timestamp is the host read time, not an instrument trigger timestamp.

**A download retrieves the latest stored record. It may predate recent settings changes.** The warning appears in both the interface and CSV metadata. The stored record's own scaling is used. To obtain fresh data, acquire a new record with Run or Single and a suitable trigger.

Export sends no acquisition-state commands. Running, stopped and armed Single exports were tested. A Single sequence may naturally finish during a download; the controller does not rearm or resume it.

Transfer source, range, byte width, binary representation, byte order and encoding are saved, restored in finally, and read back. Custom ASCII/1-byte/partial-range settings were verified to restore after a full binary export. A restoration failure returns an error rather than a successful CSV.

Channels must be enabled and have acquired data. The scope can return null/stored records for newly enabled or previewed channels; export does not force a fresh acquisition or infer validity from a flat trace.

## Acquisition and channels

**Autoset** sends the documented AUTOSET EXECUTE command. The dashboard uses bounded BUSY? polling, then reads actual settings and refreshes controls and the capture. It automatically adjusts channel, timebase and trigger settings. It does not use *OPC? or *WAI. Autoset and the resulting readback/image were verified against the connected scope, then the pre-test settings were restored with the documented Undo plus readback checks.

Run selects continuous RUNSTOP acquisition and starts it. Stop stops acquisition. Single arms SEQUENCE operation. The UI polls ACQUIRE:STATE?, TRIGGER:STATE? and ACQUIRE:STOPAFTER?, showing stopped, pretrigger, waiting for trigger and capturing states. In Average mode one sequence comprises the selected count.

Sample, Peak Detect and Average modes are available. Averaging counts are powers of two from 2 to 512 and can be set when Average is active.

Both channels support display on/off, scale, position, offset, coupling, probe attenuation, 20 MHz / 150 MHz / Full bandwidth and invert. Applied values are read back; rounded or enforced values are reported.

On the tested v3.27 firmware, CHn:PROBE 10 behaves as 10Ã— attenuation: changing it from 10 to 1 reduced the reported vertical scale by ten. This verified behavior differs from the programmer manual's inverse-gain example. Detected probes may enforce their factor; readback is authoritative. CSV conversion never applies an additional probe multiplier.

Edge trigger source, slope, level and Auto/Normal mode remain available. The controller does not replace complex trigger configurations through these simple controls.

## Channel colors and original captures

Setup saves a separate CH1 and CH2 color, with **Reset to default colors**. Dashboard channel headings/borders and measurement labels use the channel's saved color.

The documented instrument palette command offers Normal or Monochrome, not arbitrary per-channel colors. Custom captured traces therefore use a clearly labeled **dashboard display effect**. No display-palette command is sent to the scope.

The effect decodes verified 640Ã—480 indexed PNGs. Channel-specific intensity ramps are recolored inside the plot interior, preserving DPO intensity. The separate CH1/CH2 text/readout palette entries are also mapped to their selected channel colors. The frame, grid, generic text and trigger-marker palette entries retain their original colors and all glyph shapes/positions remain unchanged. It is not a global RGB search/replace. Unknown/monochrome palettes or unsupported image layouts fall back to the original image with a visible explanation.

**Show original capture** switches to the unmodified bytes for the same frame. **Save original PNG** saves those bytes. **Save displayed PNG** saves whichever view is shown. The original is retained in an in-memory cache of 16 captures; after eviction or service restart, refresh the screen to obtain a new original/display pair.

Limits:
- An overlap contains only the final rendered pixel; a hidden trace cannot be recovered or separated.
- Any unusual in-plot graphic encoded with a trace intensity index can inherit that trace color.
- Only channel-attributed text/readouts can be matched reliably. Generic text stays unchanged.
- Pixels at the frame boundary are retained; a clipped trace touching it may retain its original edge color.
- Selected colors can have different contrast against the scope's background. Use the original view for comparison.

## Named presets and layout

Named presets are stored on the Pi (up to 50). Saving the same name replaces it. The page shows each preset's saved values before recall.

Included: both channels' display, probe, scale, position, offset, coupling, bandwidth and invert; main timebase; acquisition mode/count; Edge trigger type, mode, source, slope and level.

Excluded: Run/Stop/Single arm state, waveforms, connection address, dashboard colors/measurement selection/layout, on-scope measurement slots, measurement gates/references, and other advanced scope settings. Presets currently require Edge trigger. Recall can reset averaging as the instrument applies settings. Values are read back, and differences from the request are shown. A failed recall attempts to restore the previous included settings.

Use **Rearrange panels**, drag a Move handle or use the up/down buttons, then **Done rearranging**. The order is saved per browser. Reset Layout restores the default order. CSS uses a single-column layout on narrow screens; touch handles and button alternatives are provided. Desktop and narrow mobile layouts were inspected in the browser. Physical Android touch/drag operation remains unverified.

## Menu Off and communication recovery

CLEARMENU is documented as the equivalent of MENU OFF. It was verified to complete while Single remained armed, followed by a valid screen capture. The effect on a DHCP status box still needs confirmation when that box is actually present.

There is no *OPC? or *WAI in the Menu Off path. Such a wait can remain pending while Single awaits a trigger. An early test exposed an instrument-side Ethernet stall; the scope's e*Scope interface reset recovered communication, and the saved scope settings were restored.

All instrument traffic, including screenshots, measurements, CSV, control and connection testing, uses a thread lock plus a process file lock. A socket timeout discards the unusable RPC transport and releases the locks in finally. Tests verified a timed-out HTTP handler followed by a successful real-scope request. This prevents a stuck controller lock; it cannot guarantee recovery from an instrument-side firmware stall. No automatic scope/interface reset is performed.

If the scope itself remains unresponsive, check its front panel and network. Its built-in e*Scope configuration page has a Reset Interface function which takes about a minute. This is separate from restarting the Pi web service.

## Files retained across restart

- connection.json: scope address and timeout
- appearance.json: dashboard channel colors
- measurement-selection.json: dashboard entries and On scope selection
- presets.json: named setup presets

Files are saved atomically in the application directory. Do not replace them when updating the application. Layout is in browser local storage.

The development deployment is a user service. Its files survive a Pi reboot, but this Pi currently has Linger=no: automatic startup requires a user login. This is a LAN development build without application authentication, not a final production installer.

## Installation and maintenance

On Raspberry Pi OS with Python 3 and venv support, place the source files in ~/tektronix-controller:

    python3 -m venv ~/tektronix-controller-venv
    ~/tektronix-controller-venv/bin/pip install -r ~/tektronix-controller/requirements.txt
    mkdir -p ~/.config/systemd/user
    cp ~/tektronix-controller/tektronix-controller.service ~/.config/systemd/user/
    systemctl --user daemon-reload
    systemctl --user enable --now tektronix-controller.service

Open http://PI_ADDRESS:8081/setup and test/save the instrument address. No HP-controller files or Nginx changes are required. The supplied user service uses %h so it is not tied to the username pi.

    systemctl --user status tektronix-controller.service
    systemctl --user restart tektronix-controller.service
    systemctl --user stop tektronix-controller.service
    journalctl --user -u tektronix-controller.service -n 50 --no-pager

Keep one Gunicorn worker. Threads are serialized for hardware access; multiple independently configured applications controlling the same instrument are outside this protection.

## Baseline and verification

The v0.1.0 application and service were backed up before changes:

    /home/pi/tektronix-baseline-20261113-221416.tar.gz
    SHA256: 9c0dd2b6a22418aebb661ac0d27e887b9f8ca76fc35cc1c9dd7f0233a1a837d4

The backup archive listing was verified. For rollback, stop the Tektronix user service, extract the backup under /home/pi, reload the user service definitions and start it. Back up new preference files first if you want to retain them for a later upgrade.

Offline checks cover measurement sentinels, signed sample and nonzero-offset scaling, envelope pair timing, truncated block restoration, restoration failures, timeout lock release, connection validation, and selective image recoloring. Run:

    ~/tektronix-controller-venv/bin/python -m unittest -v test_scope_io test_screen_effect

verify_live.py is an opt-in hardware test script: it temporarily changes channel, acquisition and trigger settings, exercises exports and presets, then restores its snapshot. It must not be run while preserving an in-progress acquisition. Do not run it automatically on installation.

Connected checks completed: both channel CSVs and SI scaling; invalid/off-channel measurements; exact transfer/immediate-setting restoration; continuous/stopped/armed-Single exports; Single waiting/triggered/stopped states; acquisition/channel settings; preset save/recall; Menu Off while armed; concurrent request serialization; offline Setup; configuration persistence across service restart. Additional connected checks passed: mixed-channel measurement entry save/remove/readback, four-slot application with rejection of a fifth, Autoset status/settings/image readback, and paired original/effect captures. On an actual two-channel capture, 8474 trace pixels and 2603 channel-text pixels changed color while 296123 other pixels remained byte-for-byte equal in RGB. Eleven offline regression tests pass.

Future work: a shared instrument dashboard linking Tektronix, HP 6033A, HP 34401A, HP 33120A and HP 5385A. It is not part of this standalone scope build.

## Reference

Tektronix Programmer Manual 071-0381-03:
https://download.tek.com/manual/071038103web.pdf

Relevant sections: immediate measurement DATA/type/source/units, WAVFRM?/WFMPRE?/CURVE?, acquisition state/stop-after, channel controls, display palette, MEAS1â€“MEAS4 display slots, and CLEARMENU.

## v0.2.1 image refresh fix

Automatic screen refresh now requests only the image. Acquisition status updates independently; control inputs are refreshed only at page startup, Read settings, or after an explicit control action. Front-panel changes require Read settings. Optional measurement refresh updates its readouts only.

Background refresh does not disable controls. Foreground actions cancel/supersede pending background image requests and have their own ordered queue. This does not bypass the server instrument lock: hardware traffic remains serialized.

Each new displayed frame is decoded before replacing the old image. Old image URLs are released after the replacement has painted. The last valid image remains visible on capture failure, and superseded background frames cannot overwrite a more recent user action.

Five Node-based regression scenarios cover image-only polling, foreground priority/ordering/error recovery, decoded-frame handoff and URL lifetime, stale-frame suppression, and original-image success/failure handling. Run `node test_refresh.js` from the source folder. Desktop and narrow mobile layouts were inspected in the browser; physical Android touch operation remains unverified.

Before deployment, the working v0.2.0 installation was backed up as /home/pi/tektronix-before-refresh-fix-20261113-232029.tar.gz (SHA256 a31f305291f4f855c571ca23e8737e8e7042f769be7ad607cb6e28f7911a5a7c). No HP-controller files were changed.


## v0.3.0 operating guide and documentation

The local HTML portal at /docs/ separates the operating guide from advanced technical, API, installation and recovery references. Styling, script and five actual dashboard/Setup/detail screenshots are served locally. Screenshots enlarge in a keyboard-dismissible dialog. Links use relative paths/current host. The original complete technical reference remains at /docs/reference.md.

### Measurement quality and freshness

Matching on-screen measurement slots are read directly; other entries use immediate measurements. Images and readings still arrive sequentially and can disagree during changing or noisy signals. Low-signal warnings are retained with uncertain values rather than automatically rejected. The connected CH2 low-amplitude frequency was visibly unstable; this correction does not make an unreliable frequency accurate.

Images and measurement lists show their last successful update. Failure retains the previous result with stale styling. Automatic updates delayed over 30 seconds are also marked stale. Manual snapshots retain their age label.

### Capture bundle

/api/capture-bundle collects original/effect PNGs, both available channel CSVs, measurements.json, settings.json and manifest.json. Disabled/unavailable channels produce an explanation and a partial manifest rather than invented CSV samples. Transport failure aborts. Collection is sequential and sends no acquisition-state writes: it is not a simultaneous test snapshot. Old-stored-record and host-time warnings are included.

Connected verification collected a complete ZIP with both 10,000-sample channel CSVs, valid ZIP integrity, images and settings. Acquisition remained running with RUNSTOP before/after. Existing waveform helper verifies transfer-setting restoration. No physical scope settings were deliberately changed for screenshots or this bundle check.

### Controller setup backup and restore

Setup exports a versioned JSON containing connection/timeout, channel colors, saved measurement selections and personal presets. Review validates all settings before restore. The reviewed current-preference fingerprint prevents restoring against changed preferences. Before replacement an automatic backup is saved in setup-backups/ and downloadable. A failed multi-file write restores original file bytes or absence; regression tests inject a failure to verify rollback.

Connected HTTP checks verified an identical-preference restore, prior-backup download and equality, rejection of a stale review (409), invalid backup rejection (400) and unchanged preference values. Restore does not write scope commands or restore browser-local layout. setup-backups/ is also retained across application updates.

### Fischer Lab examples

example_catalog.py holds built-ins separately from presets.json. Notes are visible before recall; incomplete recipes are blocked in both UI and API. Saving while an example is selected requires a new personal name and does not overwrite existing personal presets.

- Sony elevator: CH1 IC503 pin 38, CH2 pin 37, DC approximately 2 V/div. CPU M3 controls through IC505, not motor terminals. Exact timebase and trigger settings were not recorded; recall remains disabled.
- Sony serial: explicit proposed CH1 pin 24 SCK input, CH2 pin 26 serial-data input; DC 2 V/div, 1 ms/div, Edge CH1 falling around 2.5 V, Auto. This is a suggested start, not a verified capture. Reference pin 2 clock output, pin 3 data output; pin 25 unused.
- Both completed recipes propose physical 10x probes and matching scope 10x settings. Prior attenuation was not recorded. Wiring and switches cannot be changed by recall. Exact signal timing/amplitudes and Sony hardware operation are not verified by this release. Establish and test a configuration, then save its readback under a new personal name.

The dashboard and Setup also link back to the instrument suite using the current hostname without port 8081. The production server and HP controller remain separate and unchanged.

### Release checks and limits

24 Python regression tests pass: run `python -m unittest -v test_scope_io test_screen_effect test_archive_tools` in the controller venv. Six Node regression scenarios pass: run `node test_refresh.js`; the sixth covers stale/failed/manual-snapshot freshness. Browser verification includes desktop/mobile layouts, local assets and anchors, screenshot enlargement and recipe notes. Physical Android touch, Sony recipe captures, an actual DHCP popup, a fresh second-Pi installation and full rollback rehearsal remain unverified. The existing user service still has Linger=no on this Pi and requires login for user-service startup.

Pre-v0.3.0 backup: /home/pi/tektronix-before-capture-upgrade-20261113-234658.tar.gz
SHA256: 3ee75af8fc6e9d1f96122dd25617529501e715ac795f1c55463f2134ab2eb893

## Trigger source indicator

A channel-colored outline and TRIGGER SOURCE badge identify all measurement entries belonging to the actual Edge trigger source. The channel control panel also receives a badge. Acquisition-status polling reads trigger source/type without refreshing control inputs. External and complex trigger sources are described rather than falsely highlighting CH1/CH2. On connection failure highlighting clears. Amber measurement warnings remain text/warning icons and do not indicate trigger source.


## v0.3.1: production startup and Ethernet discovery

Trigger-source badges and channel-colored outlines follow actual Edge trigger readback without replacing control inputs. Measurement warnings use explanatory text/icons rather than a competing outline.

Initial hostname resolution, RPC portmapper discovery and TCP connect now share the configured connection-timeout budget. This closes a python-vxi11 0.9 discovery gap: its normal operation timeout was applied only after connecting. Resolver waits and sockets are bounded locally without changing global process socket settings. A failed transport is discarded, and the scope lock is released for recovery. Two regression tests cover a TCP peer that accepts but never answers discovery, and a stalled DNS lookup.

Current regression commands:

    python -m unittest -v test_scope_io test_screen_effect test_archive_tools test_ethernet_transport
    node test_refresh.js
    node test_trigger.js

The 26 Python tests and seven Node checks cover the current source. Current live checks also exercise identity, paired images, both 10,000-sample CSV records, measurement qualifiers, control readback, preset save/recall, capture bundles and recovery from an unavailable scope.

For unattended startup, enable the supplied user service and enable lingering for its account:

    systemctl --user enable --now tektronix-controller.service
    sudo loginctl enable-linger USERNAME

The deployed live account has Linger=yes. Historical notes above describe the earlier test account's Linger=no. The HP service, HTTPS/authentication configuration and private preferences are maintained separately. HP Modern and Classic navigation use the current host and scope port 8081; scope-to-suite navigation respects the suite's existing HTTP-to-HTTPS redirect.

The scope lock coordinates processes on one host. Keep the test scope service stopped while the live controller owns the instrument, so independent hosts cannot interleave transfer settings. The apps remain separate processes; a failed scope request must not block HP requests.

Repository publication excludes connection.json, appearance.json, measurement-selection.json, presets.json, setup-backups, credentials, deployment-preferences, backups and temporary captures. Personal examples and the documentation screenshots are included only in a repository verified private.


## v0.3.2: panel sizes

Choose Customize Layout to move panels or choose Default, Half width or Full width. On desktop, adjust height with the lower-right resize grip, Shorter/Taller buttons, or Auto height to let the content determine panel height. Short fixed-height panels scroll internally so controls remain accessible. Width, height and order are saved in browser local storage. Existing saved panel order is retained. Reset Layout clears both order and size preferences. At viewport widths of 900 pixels or less, panels use one column and automatic height; desktop size preferences remain stored. Layout changes do not send instrument commands. Browser-local layout is not part of controller Setup export/restore.

Browser verification: Half/Full width, Shorter/Auto height, order and size persistence across reload, Reset Layout, and a 390-pixel single-column mobile viewport passed. Existing image-refresh and trigger-indicator regression checks passed. Layout editing leaves scope control requests available. Physical Android touch operation remains unverified.

### Shared instrument menu

After successful installation, the installer registers with the optional [Fischer Instrument Suite](https://github.com/RLF62/instrument-suite) manager. Missing or busy managers report registration as pending without failing installation. Existing integrated and legacy services are protected from removal until migrated to separate services. Registration sends no instrument commands.

## Independent services behind HTTPS

The shared suite now includes the gateway and deployment-policy support used to separate legacy controllers while preserving existing HTTPS URLs and control authentication. After a completed migration, each controller can be removed and reinstalled without taking down the suite or the other instruments. See the [gateway and migration guide](https://github.com/RLF62/instrument-suite/blob/main/GATEWAY_MIGRATION.md). Existing legacy installations still require an attended migration; installing the catalog alone does not perform it.
