# Production verification — 2026-11-14

The standalone controller is v0.3.1. HP remains v1.0.2 with a navigation-only integration patch. Its live backend matched the published v1.0.2 source; older test-server HP templates were not copied over it.

Verified on the live host:

- Scope identity, original/display PNGs, measurements and qualifier explanations.
- Both 10,000-sample channel CSVs and a complete capture ZIP; transfer and immediate-measurement settings restored.
- Accepted channel/trigger/timebase readback; personal preset save/recall with the original preset file restored afterward.
- Single acquisition and Menu Off; Autoset with bounded BUSY polling and documented Undo. Channel/acquisition/trigger readback matched the pre-test snapshot afterward. No OPC/WAI wait.
- Setup connection test, saved preferences, local HTML documentation and host-relative suite navigation in both directions.
- An unavailable-address test returned in approximately 1.1 seconds while the HP status request completed in approximately 0.3 seconds. The next real-scope request recovered immediately.
- The HP hardware accepted unchanged-value voltage/current requests with output OFF. Accepted setpoints and output state were preserved. No HP output command was sent. Authentication file bytes, preset lists and display labels matched the predeployment backup.
- 26 Python scope tests, seven Node frontend checks, and all 95 HP regression tests passed. Nginx configuration validation passed.
- The scope service restarted successfully. HP/Nginx and the scope service are enabled for startup; user lingering is enabled on the live host. Full-host reboot verification is reported in the deployment handoff.

The existing HP HTTPS/authentication configuration was retained. The standalone scope interface uses the previously tested trusted-LAN HTTP service on port 8081. Runtime preferences and credentials are excluded from Git. This repository was verified private before including the user's troubleshooting examples and the approved documentation screenshots.

The test scope service is kept stopped/disabled while the live service owns the instrument. Applications on different hosts do not share the scope file lock.

Remaining limitations: Sony recipes are not verified captures; the elevator recipe lacks recorded timebase/trigger settings and cannot be recalled. Physical Android touch operation, dismissal of an actual DHCP popup, and a generic unattended installer remain unverified. Documentation screenshots show the tested dashboard and are illustrative snapshots rather than fresh instrument data.

Full-host reboot verification subsequently passed: HP, Nginx and the standalone scope service returned automatically. HP GPIB communication, accepted setpoints and output state matched the pre-reboot snapshot. Fresh scope identity, PNG and both-channel capture bundle checks passed after boot. Controller configuration/authentication file hashes were unchanged. HP remote programming returned disabled, its normal safe startup behavior.
